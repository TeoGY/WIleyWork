import java.util.Scanner;
import java.util.Random;

public class DogGenetics {

    /**
     *
     * @param args
     * Write a program that asks the user for the name of their dog, and then generates a fake DNA background report on the pet dog.
     * It should assign a random percentage to 5 dog breeds (that should add up to 100%!)
     */

    public static void main(String[] args) {

        // Ask user for their dogs name
        String dogName;
        Scanner sc = new Scanner(System.in);
        System.out.print("What is your dog's name? ");
        dogName  = sc.nextLine();
        System.out.println("Well then, I have this highly reliable report on " + dogName + "'s prestigious background right here.");
        System.out.println();
        System.out.println(dogName + " is:");
        System.out.println();

        //Calculates the genetic make-up of the first 4 dogs
        Random rng = new Random();
        int dog1 = rng.nextInt(25)+1;
        System.out.println(dog1 + "% St. Bernard");
        int dog2 = rng.nextInt(24)+1;
        System.out.println(dog2 + "% Chihuahua");
        int dog3 = rng.nextInt(25)+1;
        System.out.println(dog3 + "% Dramatic RedNosed Asian Pug");
        int dog4 = rng.nextInt(25)+1;
        System.out.println(dog4 + "% Common Cur");


        int[] dogs = {dog1 , dog2 , dog3 , dog4}; //Take the 4 dogs and store is as a value
        int dog5 = 100;
        int tBreed = 0;

        for (int i = 0; i < dogs.length; i++) {
            tBreed += dogs[i];
            //System.out.println(dogs[i]);
        }

        int lastDog = dog5 - tBreed ; // Take the value produced and take it away from 100 to produce the 5th dogs genetics
        //System.out.println(tBreed);
        System.out.println(lastDog + "% King Doberman");
        System.out.println();
        System.out.println("Wow, that's QUITE the dog!"); // Print remaining expected outcomes




    } // End of main
/**
 * Initial line of thought for solving
 *
 * Generate number between 1 and 100 = x
 * take x - 100 = y
 * generate new number between 1 and y = z
 * take z - y = 2ndDogGenetics
 */

} // End of class