import java.util.*;

public class RockPaperScissors {

    /**
     * A method called game
     */
    static void game() {
        int rounds; // declare rounds to store no. of rounds
        int playersChoice; // decision between 1, 2 or 3 (RPS)
        int currentRound = 0;
        int random = (int) (Math.random()*3) +1; // Random number generation between 1-3
        String replay;

        // Scoring tracking
        int draw = 0;
        int pWin = 0;
        int cWin = 0;

        Scanner playing = new Scanner(System.in);
        System.out.println("With a max of 10, how many rounds should we play?");
        rounds = playing.nextInt(); // Take user input for no. of rounds.

        // Check if playing within bounds, otherwise terminate
        if (rounds <= 10){
            System.out.println("Okay, lets play "+ rounds +" rounds!"); //Remind player how many rounds have been selected
            System.out.println("By the way, if you win it's only pure chance!"); // Just to immerse first time users
        } else if (rounds > 10)  {
            System.out.println("Sorry, I said out of 10, you broke that rule and I don't play with cheats!");
            System.out.println("If you do really want to play, try sticking to the rules and try again");
            System.exit(0);  // Exit game
        }
        System.out.println("Okay, here are the options: 1.Rock, 2.Paper, 3.Scissors"); // Check exit works, continue game.

        /**
         * loop through until number of rounds entered matches number of rounds played
         * Display current round
         */
        for (currentRound =1; currentRound<= rounds; currentRound++) {
            System.out.println("Round: "+ currentRound);

        //Ask user for 1. Rock, 2. Paper, 3. Scissors
        Scanner RPS = new Scanner(System.in);
        System.out.println("pick between 1, 2 or 3");
            System.out.println("1. Rock, 2. Paper or 3. Scissors");
        playersChoice = RPS.nextInt();// Takes user next integer input between

            int compChoice = random; //Randomise computer choice of R,P,S

            if (playersChoice == compChoice) {
                System.out.println("ha, I chose the same");
                System.out.println("It's a draw");
                draw++;//Increment draw score

            } else {
                switch (playersChoice) { // Switch statement to consider all possible outcomes of Rock, Paper, Scissors
                    case 1:
                        if (compChoice == 2) {
                            System.out.println("I chose 2");
                            System.out.println("Computer wins");
                            cWin++; //Increment computer score

                        } else if (compChoice == 3) {
                            System.out.println("I chose 3");
                            System.out.println("Player wins");
                            pWin++; //Increment player score

                        }
                        break;

                    case 2:
                        if (compChoice == 3) {
                            System.out.println("I chose 3");
                            System.out.println("Computer wins");
                            cWin++;
                        } else if (compChoice == 1) {
                            System.out.println("I chose 1");
                            System.out.println("Player wins");
                            pWin++;
                        }
                        break;

                    case 3:
                        if (compChoice == 1) {
                            System.out.println("I chose 1");
                            System.out.println("Computer wins");
                            cWin++;
                        } else if (compChoice == 2) {
                            System.out.println("I chose 2");
                            System.out.println("Player Wins");
                            pWin++;
                        }

                }

            }

        }
        //Prints individual outcome
        System.out.println("There were " +draw+ " draws out of " +rounds);
        System.out.println("I scored " +cWin+ " out of " +rounds);
        System.out.println("You scored " +pWin+ " out of " +rounds);

        //Checks all outcomes to prints who won
        if(draw > cWin && draw > pWin){
            System.out.println("----It's a draw!");
        } else if (cWin > draw && cWin > pWin) {
            System.out.println("--- COMPUTER WINS");
        } else if (pWin > draw && pWin > cWin) {
            System.out.println("--- PLAYER WINS");
        } else if (pWin == draw && cWin < draw  ) {
            System.out.println("---Player win");
        } else if(cWin == draw && pWin < draw){
            System.out.println("---COMPUTER WINS");
        } else if (cWin == draw && draw == pWin) {
            System.out.println("----It's a draw!");
        }
        System.out.println();
        //Scanner YoN = new Scanner(System.in);
        System.out.println("Want to play again");
        System.out.println("Yes or No");
        replay = playing.next(); //Ask user if they would like to play again


        /**
         * If user inputs "yes" game will be reloaded from start,
         * Otherwise print message and exit game.
         */
        System.out.println(replay);
        if (replay.equalsIgnoreCase("Yes")){
            game();
        } else if (replay.equalsIgnoreCase("No")) {
            System.out.print("Thanks for playing!");
            System.exit(0);
        }


        /**
         * Practice code
         *
         *
           for (currentRound =1; currentRound<= rounds; currentRound++) {

               System.out.println("Round: "+ currentRound);

               Random rng = new Random(); //
               //for (int x=0; x<= 0; x++) {
                   int randomNumber = rng.nextInt(3)+1; // generate a random number between 1 and 3
                   System.out.println(randomNumber); // Print to convince user of outcome
              // }
               //currentRound++;
           } */


    } // End of main

    //Any methods can go here


    public static void main(String[] args) {
      game(); // Initialise game by calling method game()
    }

} // End of Class