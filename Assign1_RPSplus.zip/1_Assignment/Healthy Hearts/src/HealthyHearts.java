import java.util.Scanner;

/**
 * Make a simple calculator that asks the user for their age. Then calculate the healthy heart rate range for that age, and display it.
 */
public class HealthyHearts {

    public static void main(String[] args) {

        // Request user for age
        int age;
        Scanner sc = new Scanner(System.in);
        System.out.println("What's your age?");
        age = sc.nextInt();

        //If/Else statement to create different bounds based on age range.
        if (age <= 1 || age <= 10) {
            System.out.println("your maximum heart rate should be 100 beats per minute - At the age of: " + age);
            System.out.println("Your target heart rate zone is between 50 - 85 beats per minute");
        } else if (age <= 18 || age <= 25) {
            System.out.println("your maximum heart rate should be 120 beats per minute - At the age of: " + age);
            System.out.println("Your target heart rate zone is  between 60 - 102 beats per minute");
        } else if (age <= 26 || age <= 35) {
            System.out.println("your maximum heart rate should be 140 beats per minute - At the age of: " + age);
            System.out.println("Your target heart rate zone is  between 70 - 119 beats per minute");
        } else if (age <= 36 || age <= 45) {
            System.out.println("your maximum heart rate should be 160 beats per minute - At the age of: " + age);
            System.out.println("Your target heart rate zone is between 80 - 136 beats per minute");
        } else if (age <= 46 || age <= 55) {
            System.out.println("your maximum heart rate should be 180 beats per minute - At the age of: " + age);
            System.out.println("Your target heart rate zone is between 90 - 153 beats per minute");
        } else if (age <= 56 || age <= 65) {
            System.out.println("your maximum heart rate should be 200 beats per minute - At the age of: " + age);
            System.out.println("Your target heart rate zone is between 100 - 170 beats per minute");
        } else if (age > 65) {
            System.out.println("your maximum heart rate should be 220 beats per minute - At the age of: " + age);
            System.out.println("Your target heart rate zone is between 50 - 187 beats per minute");
        }
    }
}
