package com.sg.VendingMachine.dto;

public class Item {

    private String slotId;
    private String itemName;
    private String itemCost;
    private String itemQuantity;

    public Item(String slotId) {
        this.slotId = slotId;
    }

    public Item(String slotId, String itemName, String itemCost, String itemQuantity) {
        this.slotId = slotId;
        this.itemName = itemName;
        this.itemCost = itemCost;
        this.itemQuantity = itemQuantity;
    }
    public Item() {

    }
    public String getSlotId() {
        return slotId;
    }

    public void setSlotId(String slotId) {
        this.slotId = slotId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getItemCost() {
        return itemCost;
    }

    public void setItemCost(String itemCost) {
        this.itemCost = itemCost;
    }

    public String getItemQuantity() {
        return itemQuantity;
    }

    public void setItemQuantity(String itemQuantity) {
        this.itemQuantity = itemQuantity;
    }

}
