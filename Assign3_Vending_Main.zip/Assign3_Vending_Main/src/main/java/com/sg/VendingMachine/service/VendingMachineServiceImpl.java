package com.sg.VendingMachine.service;

import com.sg.VendingMachine.dao.VendingMachineAuditDao;
import com.sg.VendingMachine.dao.VendingMachineDao;
import com.sg.VendingMachine.dao.VendingMachinePersistenceException;
import com.sg.VendingMachine.dto.Change;
import com.sg.VendingMachine.dto.Item;

import java.math.BigDecimal;
import java.util.List;

public class VendingMachineServiceImpl implements VendingMachineServiceLayer {

    private VendingMachineDao dao;
    private VendingMachineAuditDao auditDao;
    private BigDecimal currentBalance;
    private BigDecimal TotalBalance = new BigDecimal("0.00");
    private BigDecimal noBalance = new BigDecimal("0.00");

    public VendingMachineServiceImpl(VendingMachineDao dao, VendingMachineAuditDao auditDao) {
        this.dao = dao;
        this.auditDao = auditDao;
    }

    public VendingMachineServiceImpl() {
        super();
    }

    @Override
    public void startVending() throws VendingMachinePersistenceException {
        dao.loadRoster(); //Start the vending machine by loading in the inventory values

    } // Conventionally, should rename but helpful proved helpful when pinpointing similarities from Code-along

    @Override
    public void endVending() throws VendingMachinePersistenceException {
        dao.writeRoster(); // Saves the current inventory
    }

    @Override
    public List<Item> getAllInventory() {
        return dao.getAllItems();
    }

    @Override
    public Item getOneItem(String atSlotId) {
        return dao.getAnyItem(atSlotId);
    }
    // Returns one item, can be any item, by calling the slot Id

    @Override
    public Change purchaseItem(String aSlotId, BigDecimal money)
            throws VendingMachinePersistenceException,
            VendingMachineInsufficientFundsException,
            VendingMachineNoItemInventoryException {

        Item currentItem = getOneItem(aSlotId);
        if (currentItem == null) {
            throw new VendingMachineNoItemInventoryException("Item appears to be out of stock");
            //This check will print if user inputs value outside vending machine range
        }
        int quantity = Integer.parseInt(currentItem.getItemQuantity()); // quantity = items in stock
        BigDecimal itemInBigDecimal = getItemInBigDecimal(currentItem); // gets current item cost in Big Decmial

        if(quantity > 0) { //If item in stock, step in.
            // Need to work out if user has enough money and assign money as Pennies "1"
            int compareBD = compareBalance(money, itemInBigDecimal); // Use compareTo
            if (compareBD == 0 || compareBD == 1) {
                money = priceToBalance(compareBD, money, itemInBigDecimal);
                BigDecimal moneyIntoPennies = money.multiply(new BigDecimal("100"));

                Change change = new Change(moneyIntoPennies); //Instantiates Change
                change.createCoins(); // Working out the amount of coins to return
                setBalance(money); // New balance
                quantity -= 1; // Reduce stock by 1 from inventory
                currentItem.setItemQuantity(String.valueOf(quantity)); // valueOf (Convert to string)
                setTotalBalance((new BigDecimal("0.00"))); // Reset balance to zero, once change has been returned
                //Update dao, write to audit file
                dao.updateAnyItem(aSlotId, currentItem);
                auditDao.writeAuditEntry(currentItem.getItemName() + " was purchased");

                return change;
            }  else {
                throw new VendingMachineInsufficientFundsException("Insufficient funds! Only inserted $" + money + " when item costs $" + currentItem.getItemCost());

            }
        } else {
            throw new VendingMachineNoItemInventoryException("No such item in inventory.");
        }
    }


    public BigDecimal getBalance() {
        return this.currentBalance;
    }

    public void setBalance(BigDecimal currentBalance) {
       this.currentBalance = currentBalance;
       TotalBalance = currentBalance.add(TotalBalance);
    }

    public BigDecimal getTotalBalance() {
        return this.TotalBalance;
    } //Total balance Big decimal

    public void setTotalBalance(BigDecimal TotalBalance) {
        this.TotalBalance = TotalBalance;
    }

    private BigDecimal getItemInBigDecimal(Item item) {
        BigDecimal itemInBigDecimal = new BigDecimal(item.getItemCost());
        return itemInBigDecimal;
        //Item's cost is big decimal, "Precise".
    }

    private int compareBalance(BigDecimal money,BigDecimal itemInBigDecimal) {
        return money.compareTo(itemInBigDecimal);
        //Will be using CompareTo to compare item cost with balance in purchase method
    }

    private BigDecimal priceToBalance(int compareValue, BigDecimal money, BigDecimal itemCost) {
        switch (compareValue) {
            case 1:
                money = money.subtract(itemCost);
                break;
            case 0:
                money = noBalance;
                break;
        }
        return money;
        // Takes away item cost from money
    }
}
