package com.sg.VendingMachine.dao;


public interface VendingMachineAuditDao {
    /**
     *
     * @param entry An entry to the log file
     * @throws VendingMachinePersistenceException If any problems occur writing the audit file
     */
    public void writeAuditEntry(String entry) throws VendingMachinePersistenceException;
}

//MIMIC ClassRosterAudit