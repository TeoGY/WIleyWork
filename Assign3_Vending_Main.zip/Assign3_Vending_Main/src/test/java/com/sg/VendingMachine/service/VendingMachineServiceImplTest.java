package com.sg.VendingMachine.service;

import com.sg.VendingMachine.dto.Item;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import static org.junit.jupiter.api.Assertions.*;

class VendingMachineServiceImplTest {

    VendingMachineServiceImpl testService;

    public VendingMachineServiceImplTest() {
        testService = new VendingMachineServiceImpl();
    }

    @org.junit.jupiter.api.Test

    @Test
    public void testGetOneItem() {
        Item item = testService.getOneItem("001");
        Assertions.assertNotNull(item);
        item = testService.getOneItem("008");
        Assertions.assertNull(item);
    }
}