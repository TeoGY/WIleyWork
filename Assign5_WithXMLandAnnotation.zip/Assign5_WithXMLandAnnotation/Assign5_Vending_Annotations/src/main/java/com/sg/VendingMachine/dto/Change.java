package com.sg.VendingMachine.dto;

import java.math.BigDecimal;

public class Change {

    private int numQuarters;
    private int numDimes;
    private int numNickles;
    private int numPennies;
    private BigDecimal totalChange;

    public Change(BigDecimal totalChange) {
        this.totalChange = totalChange;
    }

    public BigDecimal getTotalChange() {
        return getTotalChange();
    }

    public int getNumQuarters() {
        return numQuarters;
    }

    public void setNumQuarters(int numQuarters) {
        this.numQuarters = numQuarters;
    }

    public int getNumDimes() {
        return numDimes;
    }

    public void setNumDimes(int numDimes) {
        this.numDimes = numDimes;
    }

    public int getNumNickles() {
        return numNickles;
    }

    public void setNumNickles(int numNickles) {
        this.numNickles = numNickles;
    }

    public int getNumPennies() {
        return numPennies;
    }

    public void setNumPennies(int numPennies) {
        this.numPennies = numPennies;
    }

    /**
     * The two methods below work together, it is used when figuring out how much change the user needs to receive
     * checks that while the total amount of change due hasn't reached zero (so fully returned).
     *
     * Step in and loops around the value of the coin, subtracting it from the total change that is due
     * and incrementing the amount of coins using addCoin() method
     */
    public void createCoins() {
        while (totalChange.intValueExact() > 0) { // While
            while (totalChange.intValueExact() >= 25) {
                addCoin(Coin.QUARTERS);
                totalChange = totalChange.subtract(new BigDecimal("25"));
            }
            while (totalChange.intValueExact() >= 10) {
                addCoin(Coin.DIMES);
                totalChange = totalChange.subtract(new BigDecimal("10"));
            }
            while (totalChange.intValueExact() >= 5) {
                addCoin(Coin.NICKLES);
                totalChange = totalChange.subtract(new BigDecimal("5"));
            }
            while (totalChange.intValueExact() >= 1) {
                addCoin(Coin.PENNIES);
                totalChange = totalChange.subtract(new BigDecimal("1"));
            }
        }
    }


    private void addCoin(Coin coin) {
        switch (coin) { // CHECK WHICH COIN TO INCREMENT BY 1
            case QUARTERS:
                numQuarters++;
                break;
            case DIMES:
                numDimes++;
                break;
            case NICKLES:
                numNickles++;
                break;
            case PENNIES:
                numPennies++;
                break;
        }
    }


}
