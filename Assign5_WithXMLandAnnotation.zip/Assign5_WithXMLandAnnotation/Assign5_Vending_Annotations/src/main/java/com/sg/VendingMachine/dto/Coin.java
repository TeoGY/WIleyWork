package com.sg.VendingMachine.dto;

public enum Coin {
    QUARTERS, DIMES, NICKLES, PENNIES
}
    /**
     * Enums are constants and so, are used to represent values which won't be subject to change
     * like Days of the week or Coin values in this instance
     *
     * Enum Class is used in Change where the value is assigned using Big Decimal to give exact values
     */

