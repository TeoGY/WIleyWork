package com.sg.VendingMachine.ui;
import com.sg.VendingMachine.dto.Change;
import com.sg.VendingMachine.dto.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

@Component
public class VendingMachineView {

    private VendingMachineUserIO io;

    @Autowired
    public VendingMachineView(VendingMachineUserIO io){
        this.io = io;
    }

    /**
     *
     * @param balance The amount of money available to the user
     * @return prompt user for an input between 1 and 3 to navigate vending
     */
    public int printMenuAndGetSelection(BigDecimal balance) {

        io.print("|==================|");
        io.print("|    Vender 3000   |");
        io.print("|Balance - $" + balance +"   |"); //  io.print("\nBalance: $" + balance); // Maybe remove this
        io.print("|1. Insert Money   |");
        io.print("|2. Purchase Item  |");
        io.print("|3. Exit           |");
        io.print("|==================|");

        return io.readInt("Please select from the" + " above choices.", 1, 3);
    }


    /**
     * @param itemList The list of items in the inventory
     * Displays items in the inventory
     * by Slot Id, item name, it's cost in $
     * and the amount of stock left
     */
    public void displayItemList(List<Item> itemList) {
            for(Item currentItem : itemList) {
                io.print(currentItem.getSlotId() + ": " + // Alternatively "\t" would create a table space
                        currentItem.getItemName() + " $" +
                        currentItem.getItemCost() + "  " +
                        currentItem.getItemQuantity() + "-Stock");
            }
            io.readString("Please hit enter to continue.");
    }

    public BigDecimal addMoney() {
        return new BigDecimal(io.readString("Enter an amount of money to add: ")); //Prompt user to add money to their balance
    }

    public String selectSlotId() {
        return io.readString("Enter the slot ID of the item you wish to purchase: e.g.'003'"); //Prompt user for slotId when purchasing item
    }

    /**
     *
     * @param change The amount of coins to be returned
     * @param item The item purchased
     * @param changeDue The total amount of money/change to be returned after the transaction
     */
    public void displayChange(Change change, Item item, BigDecimal changeDue) {
        if (change != null) {
            io.print("Thank you for purchasing " + item.getItemName());
            io.print("Your change is $" + changeDue);
            io.print("Here's your break down");
            io.print("Quarters: " + change.getNumQuarters());
            io.print("Dimes: " + change.getNumDimes());
            io.print("Nickles: " + change.getNumNickles());
            io.print("Pennies: " + change.getNumPennies());
        } else {
            System.out.println("Items out");
        }
        io.readString("Press enter to continue");
    }

    /**
     * The three methods below provide user functionality
     * with text informing them of an invalid command or new state
     */
    public void displayExitBanner(){
        io.print("Good Bye!");
    }

    public void displayUnknownCommandBanner(){
        io.print("UnknownCommand");
    }

    public void displayErrorMessage(String errorMsg) {
        io.print("=== Error ===");
        io.print(errorMsg);
        io.readString("Press enter to continue");
    }

    /* Didn't end up needing/Using this method
    public void displayItemSuccessfullyPurchased(Item item) {
        io.print(item + "was successfully purchased");

    }*/

}