package com.sg.VendingMachine.dao;

import com.sg.VendingMachine.dao.VendingMachinePersistenceException;
import com.sg.VendingMachine.dto.Item;
import java.util.List;

public interface VendingMachineDao {

    public List<Item> getAllItems();
    public Item addItem(Item anyItem, String slotId);
    public Item getAnyItem(String slotId);
    public void updateAnyItem(String slotId, Item changeItem);
    public Item removeAnyItem(String slotId);

    public void loadRoster() throws VendingMachinePersistenceException;
    public void writeRoster() throws VendingMachinePersistenceException;

}
