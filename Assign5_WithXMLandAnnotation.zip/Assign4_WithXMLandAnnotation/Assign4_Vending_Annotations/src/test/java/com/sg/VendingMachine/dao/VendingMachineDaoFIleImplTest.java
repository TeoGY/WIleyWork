package com.sg.VendingMachine.dao;

import com.sg.VendingMachine.dto.Item;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class VendingMachineDaoFIleImplTest {

    VendingMachineDaoFIleImpl testDao;

    public VendingMachineDaoFIleImplTest() {
        testDao = new VendingMachineDaoFIleImpl();
    }


    @Test
    void TestMarshallItem() {
        //Arrange
        Item item = new Item("001", "Double Twix","2.00","4");
        //Act
        String itemAsText = testDao.marshallItem(item);
        //Assert
        Assertions.assertEquals("001::Double Twix::2.00::4", itemAsText);
    }
}