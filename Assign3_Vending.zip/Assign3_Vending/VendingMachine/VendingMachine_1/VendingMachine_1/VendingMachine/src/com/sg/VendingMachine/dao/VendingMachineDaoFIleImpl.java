package com.sg.VendingMachine.dao;

import com.sg.VendingMachine.dto.Item;
import java.io.*;
import java.util.*;

public class VendingMachineDaoFIleImpl implements VendingMachineDao {

    public final String INVENTORY_FILE ; //= "inventory.txt"
    public static final String DELIMITER = "::";
    private Map<String, Item> items = new HashMap<>();

    /**/public VendingMachineDaoFIleImpl() {
        //items = new HashMap<>();
        this.INVENTORY_FILE = "Inventory.txt";
    }

    public VendingMachineDaoFIleImpl(String fileName) {
        //items = new HashMap<>();
        this.INVENTORY_FILE = fileName;
    }

    @Override
    public List<Item> getAllItems() {
        return new ArrayList<Item>(items.values());
    }

    @Override
    public Item addItem(Item anyItem, String slotId) {
        Item storingId = items.put(slotId, anyItem);
        return storingId;
    }

    @Override
    public Item getAnyItem(String slotId) {
        return items.get(slotId);
    }

    @Override
    public void updateAnyItem(String slotId, Item changeItem) {
        items.replace(slotId, changeItem);
    }

    @Override
    public Item removeAnyItem(String slotId) {
        Item removedItem = items.remove(slotId);
        return removedItem;
    }

    public Item unmarshallItem(String itemAsText) {
        Item inventoryItem = new Item();
        String[] itemDetails = itemAsText.split(DELIMITER);

        inventoryItem.setSlotId(itemDetails[0]);
        inventoryItem.setItemName(itemDetails[1]);
        inventoryItem.setItemCost(itemDetails[2]);
        inventoryItem.setItemQuantity(itemDetails[3]);

        return inventoryItem;
    }

    public String marshallItem(Item anyItem) {
        String itemAsText = ""; // Empty
        itemAsText = anyItem.getSlotId() + DELIMITER;

        itemAsText += anyItem.getItemName() + DELIMITER;

        itemAsText += anyItem.getItemCost() + DELIMITER;

        itemAsText += anyItem.getItemQuantity();

        return itemAsText;

    }

    @Override
    public void loadRoster() throws VendingMachinePersistenceException {
        Scanner scanner;

        try{
            // Create Scanner for reading the file
           scanner = new Scanner(
                   new BufferedReader(
                           new FileReader("inventory.txt")));
        } catch (FileNotFoundException e){
            throw new VendingMachinePersistenceException(" -_- Could not load roster data in memory.",e);
        }
        String currentLine;
        Item currentItem;

        while (scanner.hasNextLine()) {
            // get the next line in the file
            currentLine = scanner.nextLine();
            currentItem = unmarshallItem(currentLine);
            items.put(currentItem.getSlotId(), currentItem);
        }
        // close scanner
        scanner.close();
    }

    public void writeRoster() throws VendingMachinePersistenceException {

        PrintWriter out;

        try {
            out = new PrintWriter(new FileWriter(INVENTORY_FILE));
        } catch (IOException e) {
            throw new VendingMachinePersistenceException(
                    "Could not save item data.", e);
        }

        String itemAsText;
        List<Item> itemList = this.getAllItems();
        for (Item currentItem : itemList) {
            // turn an item into a String
            itemAsText = marshallItem(currentItem);
            // write the item object to the file
            out.println(itemAsText);
            // force PrintWriter to write line to the file
            out.flush();
        }
        // Clean up
        out.close();
    }
}

