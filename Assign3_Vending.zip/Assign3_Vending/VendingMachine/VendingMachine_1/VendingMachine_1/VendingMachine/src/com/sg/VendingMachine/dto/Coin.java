package com.sg.VendingMachine.dto;

public enum Coin {
    QUARTERS, DIMES, NICKLES, PENNIES
}
