package com.sg.VendingMachine.dto;

import java.math.BigDecimal;

public class Change {

    private int numQuarters;
    private int numDimes;
    private int numNickles;
    private int numPennies;
    private BigDecimal totalChange;

    public Change(BigDecimal totalChange) {
        this.totalChange = totalChange;
    }

    public BigDecimal getTotalChange() {
        return getTotalChange();
    }

    public int getNumQuarters() {
        return numQuarters;
    }

    public void setNumQuarters(int numQuarters) {
        this.numQuarters = numQuarters;
    }

    public int getNumDimes() {
        return numDimes;
    }

    public void setNumDimes(int numDimes) {
        this.numDimes = numDimes;
    }

    public int getNumNickles() {
        return numNickles;
    }

    public void setNumNickles(int numNickles) {
        this.numNickles = numNickles;
    }

    public int getNumPennies() {
        return numPennies;
    }

    public void setNumPennies(int numPennies) {
        this.numPennies = numPennies;
    }


    public void createCoins() {
        while (totalChange.intValueExact() > 0) {
            while (totalChange.intValueExact() >= 25) {
                addCoin(Coin.QUARTERS);
                totalChange = totalChange.subtract(new BigDecimal("25"));
            }
            while (totalChange.intValueExact() >= 10) {
                addCoin(Coin.DIMES);
                totalChange = totalChange.subtract(new BigDecimal("10"));
            }
            while (totalChange.intValueExact() >= 5) {
                addCoin(Coin.NICKLES);
                totalChange = totalChange.subtract(new BigDecimal("5"));
            }
            while (totalChange.intValueExact() >= 1) {
                addCoin(Coin.PENNIES);
                totalChange = totalChange.subtract(new BigDecimal("1"));
            }
        }
    }

    private void addCoin(Coin coin) {
        switch (coin) {
            case QUARTERS:
                numQuarters++;
                break;
            case DIMES:
                numDimes++;
                break;
            case NICKLES:
                numNickles++;
                break;
            case PENNIES:
                numPennies++;
                break;
        }
    }


}
