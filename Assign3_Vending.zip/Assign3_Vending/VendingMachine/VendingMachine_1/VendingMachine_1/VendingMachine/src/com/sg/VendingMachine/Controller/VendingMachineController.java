package com.sg.VendingMachine.Controller;

import com.sg.VendingMachine.dao.VendingMachinePersistenceException;
import com.sg.VendingMachine.dto.Change;
import com.sg.VendingMachine.dto.Item;
import com.sg.VendingMachine.service.VendingMachineInsufficientFundsException;
import com.sg.VendingMachine.service.VendingMachineNoItemInventoryException;
import com.sg.VendingMachine.service.VendingMachineServiceImpl;
import com.sg.VendingMachine.ui.VendingMachineView;

import java.math.BigDecimal;
import java.util.List;


public class VendingMachineController {
    private VendingMachineView view;
    private VendingMachineServiceImpl service;

    public VendingMachineController(VendingMachineServiceImpl service, VendingMachineView view){
        this.service = service;
        this.view = view;
    }

    public void run() {
        boolean keepGoing = true;
        int menuSelection = 0;

        try{
            service.startVending();

            //vending(); //Initialise VendingMachine Services
            while (keepGoing) {
                System.out.println("Here is what's on sale: \n");
                listItems();
                menuSelection = getMenuSelection();


                switch (menuSelection) {
                    case 1:
                        service.setBalance(insertMoney());
                        //System.out.println(" PLACE HOLDER - INSERT MONEY");
                        break;
                    case 2:
                        purchaseItem();
                        //service.purchaseItem("1", BigDecimal(100)); Invalid
                        //System.out.println(" PLACE HOLDER - SELECT/PURCHASE ITEM");
                        break;
                    case 3:
                        //System.out.println(" Perform SAVE ON EXIT METHOD");
                        keepGoing = false;
                        saveChanges();
                        break;
                    default:
                        unknownCommand();
                }
            }
            exitMessage();
        } catch (VendingMachinePersistenceException e){
            view.displayErrorMessage(e.getMessage());
        }
    }

    private int getMenuSelection(){
        return view.printMenuAndGetSelection(service.getTotalBalance());
    }

    private BigDecimal insertMoney() {
        return view.addMoney();
    }

    private void listItems() {
        List<Item> itemList = service.getAllInventory();
        view.displayItemList(itemList);
    }

    private void purchaseItem()throws VendingMachinePersistenceException{



        try {
            String slotId = view.selectSlotId();
            Change change = service.purchaseItem(slotId, service.getTotalBalance());
            view.displayChange(change, service.getOneItem(slotId), service.getBalance());

        } catch (VendingMachineInsufficientFundsException | VendingMachineNoItemInventoryException e) {

            view.displayErrorMessage(e.getMessage());
        }
    }

    private void saveChanges() throws VendingMachinePersistenceException{
        service.endVending();
    }

    /*private void vending() throws VendingMachinePersistenceException{
        service.startVending();
    }*/

    public void unknownCommand(){
        view.displayUnknownCommandBanner();
    }

    public void exitMessage(){
        view.displayExitBanner();
    }
}
