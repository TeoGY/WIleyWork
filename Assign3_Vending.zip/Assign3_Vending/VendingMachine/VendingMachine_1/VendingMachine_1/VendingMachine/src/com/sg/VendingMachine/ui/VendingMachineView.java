package com.sg.VendingMachine.ui;
import com.sg.VendingMachine.dto.Change;
import com.sg.VendingMachine.dto.Item;
import java.math.BigDecimal;
import java.util.List;

public class VendingMachineView {

    private VendingMachineUserIO io;

    public VendingMachineView(VendingMachineUserIO io){
        this.io = io;
    }

    public int printMenuAndGetSelection(BigDecimal balance) {

        io.print("Main Menu");
        io.print("Balance - $" + balance); //  io.print("\nBalance: $" + balance); // Maybe remove this
        io.print("1. Insert Money");
        io.print("2. Purchase Item");
        io.print("3. Exit");


        return io.readInt("Please select from the" + " above choices.", 1, 3);
    }


        public void displayItemList(List<Item> itemList) {
            for(Item currentItem : itemList) {
                io.print(currentItem.getSlotId() + ": " + // Alternatively "\t" would create a table space
                        currentItem.getItemName() + " $" +
                        currentItem.getItemCost() + "  " +
                        currentItem.getItemQuantity() + "-Stock");
            }
            io.readString("Please hit enter to continue.");
    }

    public BigDecimal addMoney() {
        return new BigDecimal(io.readString("Enter an amount of money to add: "));
    }

    public String selectSlotId() { // GetsSlotIDChoice
        return io.readString("Enter the slot ID of the item you wish to purchase: e.g.'003'");
    }

    /*public void displayItemSuccessfullyPurchased(Item item) {
        io.print(item + "was successfully purchased");
    }*/

    public void displayChange(Change change, Item item, BigDecimal changeDue) {
        if (change != null) {
            io.print("Thank you for purchasing " + item.getItemName());
            io.print("Your change is $" + changeDue);
            io.print("Here's your break down");
            io.print("Quarters: " + change.getNumQuarters());
            io.print("Dimes: " + change.getNumDimes());
            io.print("Nickles: " + change.getNumNickles());
            io.print("Pennies: " + change.getNumPennies());
        } else {
            System.out.println("Items out");
        }
        io.readString("Press enter to continue");
    }

    public void displayExitBanner(){
        io.print("Good Bye!");
    }

    public void displayUnknownCommandBanner(){
        io.print("UnknownCommand");
    }

    public void displayErrorMessage(String errorMsg) {
        io.print("=== Error ===");
        io.print(errorMsg);
        io.readString("Press enter to continue");
    }

}