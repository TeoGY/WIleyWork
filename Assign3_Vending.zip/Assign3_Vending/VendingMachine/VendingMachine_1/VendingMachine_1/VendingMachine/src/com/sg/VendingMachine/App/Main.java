package com.sg.VendingMachine.App;


import com.sg.VendingMachine.Controller.VendingMachineController;
import com.sg.VendingMachine.dao.*;
import com.sg.VendingMachine.service.VendingMachineServiceImpl;
import com.sg.VendingMachine.ui.VendingMachineUserIO;
import com.sg.VendingMachine.ui.VendingMachineUserIOConsoleImpl;
import com.sg.VendingMachine.ui.VendingMachineView;

public class Main {
    public static void main(String[] args) {
        VendingMachineUserIO myIo = new VendingMachineUserIOConsoleImpl(); // Instantiate the UserIO impl
        VendingMachineView myView = new VendingMachineView(myIo); //Instantiate the view and pass UserIO in view
        VendingMachineDao myDao = new VendingMachineDaoFIleImpl(); //Instantiate DAO, myDao
        VendingMachineAuditDao myAuditDao = new VendingMachineAuditDaoFileImpl(); //Instantiate Audit DAO
        VendingMachineServiceImpl myService = new VendingMachineServiceImpl(myDao, myAuditDao); //Instantiate service layer, passing DAO and Audit DAO
        VendingMachineController controller = new VendingMachineController(myService, myView); //Instantiate the Controller with Service layer and View

        controller.run();  //Kick All of this off - Starts Program (Runs Main method)
    }
}
// Mimicked ClassRoster