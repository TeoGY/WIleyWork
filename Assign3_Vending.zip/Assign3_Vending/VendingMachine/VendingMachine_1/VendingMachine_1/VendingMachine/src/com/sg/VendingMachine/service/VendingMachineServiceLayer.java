package com.sg.VendingMachine.service;


import com.sg.VendingMachine.dao.VendingMachinePersistenceException;
import com.sg.VendingMachine.dto.Change;
import com.sg.VendingMachine.dto.Item;
import java.math.BigDecimal;
import java.util.List;

public interface VendingMachineServiceLayer {

    public void startVending() throws VendingMachinePersistenceException;
    public void endVending() throws VendingMachinePersistenceException;

    public List<Item> getAllInventory();
    public Item getOneItem(String atSlotId);
    public Change purchaseItem(String atSlotId, BigDecimal money) throws VendingMachinePersistenceException,
            VendingMachineInsufficientFundsException,
            VendingMachineNoItemInventoryException;


}
