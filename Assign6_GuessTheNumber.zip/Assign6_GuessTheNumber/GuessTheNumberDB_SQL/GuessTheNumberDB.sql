drop database if exists GuessTheNumberDB;

create database GuessTheNumberDB;

use GuessTheNumberDB;

CREATE TABLE games (
  game_id INTEGER PRIMARY KEY AUTO_INCREMENT,
  answer INTEGER NOT NULL,
  states VARCHAR(255) NOT NULL,
  start_time DATETIME NOT NULL,
  end_time DATETIME
);

INSERT INTO games(game_id, answer, states, start_Time, end_Time ) VALUES
	(1, "1234", true, "2022-12-03 07:25:18", null);
#	(2, "1753", true);
#	(3, "4321", true); 


CREATE TABLE rounds (
  round_id INTEGER PRIMARY KEY AUTO_INCREMENT,
  game_id INTEGER NOT NULL,
  guess INTEGER NOT NULL,
  time DATETIME NOT NULL,
  exact_matches INTEGER NOT NULL,
  partial_matches INTEGER NOT NULL,
  FOREIGN KEY (game_id) REFERENCES games(game_id)
);
INSERT INTO rounds (round_Id, game_Id, guess, time, exact_matches, partial_matches) VALUES 
    (1, 1, "2349", "2022-12-03 09:10:18", "0", "3"),
    (2, 1,  "9234", "2022-12-02 09:11:07", "3", "0"),
    (3, 1,  "1234", "2022-12-04 09:11:49", "4", "0");

	select * from games;
    select * from rounds;


