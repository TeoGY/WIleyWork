package com.example.guessthenumber;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GuessthenumberApplication {

	public static void main(String[] args) {
		SpringApplication.run(GuessthenumberApplication.class, args);
	}

}
