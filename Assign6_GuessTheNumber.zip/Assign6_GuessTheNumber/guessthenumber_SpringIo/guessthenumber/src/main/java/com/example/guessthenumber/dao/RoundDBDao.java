package com.example.guessthenumber.dao;

import com.example.guessthenumber.models.Round;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class RoundDBDao implements RoundDao{
    private JdbcTemplate jdbcTemplate;

    @Autowired
    public RoundDBDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<Round> getAllRounds() {
        String sql = "SELECT * FROM rounds";
        return jdbcTemplate.query(sql, new RoundMapper());
    }

    @Override
    public Round getRoundById(int roundId) {
        String sql = "SELECT * FROM rounds WHERE round_id = ?";
        return jdbcTemplate.queryForObject(sql, new RoundMapper(), roundId);
    }

    @Override
    public List<Round> getRoundsByGameId(int gameId) {
        return null;
    }

    @Override
    @Transactional
    public void addRound(Round round) {
        String sql = "INSERT INTO rounds (game_id, guess, time, exact_matches, partial_matches) VALUES (?, ?, ?, ?, ?)";
        jdbcTemplate.update(sql,
                round.getGameId(),
                round.getGuess(),
                round.getTime(),
                round.getExactMatches(),
                round.getPartialMatches());
    }

    @Override
    public void updateRound(Round round) {
        String sql = "UPDATE rounds SET game_id = ?, guess = ?, time = ?, exact_matches = ?, partial_matches = ? WHERE round_id = ?";
        jdbcTemplate.update(sql,
                round.getGameId(),
                round.getGuess(),
                round.getTime(),
                round.getExactMatches(),
                round.getPartialMatches(),
                round.getRoundId());
    }


    private static final class RoundMapper implements RowMapper<Round> {
        @Override
        public Round mapRow(ResultSet rs, int rowNum) throws SQLException {
            Round round = new Round();
            round.setRoundId(rs.getInt("round_id"));
            round.setGameId(rs.getInt("game_id"));
            round.setGuess(rs.getInt("guess"));
            round.setTime(rs.getDate("time"));
            round.setExactMatches(rs.getInt("exact_matches"));
            round.setPartialMatches(rs.getInt("partial_matches"));
            return round;
        }

    }
}
