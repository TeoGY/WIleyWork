package com.example.guessthenumber.models;

import java.sql.Date;
import java.time.LocalDateTime;


public class Game {
    private int gameId;
    private String answer;
    private String states;
    private Date startTime;
    private Date endTime;

    //Constructors

    public Game() {
        // Initialize fields to default values
        this.gameId = 0;
        this.answer = "";
        this.states = "";
        this.startTime = null;
        this.endTime = null;
    }

    public Game(int gameId, String answer, String states, Date startTime, Date endTime) {
        this.gameId = gameId;
        this.answer = answer;
        this.states = states;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    //Getters & Setters
    public int getGameId() {
        return gameId;
    }

    public void setGameId(int gameId) {
        this.gameId = gameId;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getStates() {
        return states;
    }

    public void setStates(String states){
        this.states = states;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    @Override
    public String toString() {
        return "Game{" +
                "gameId=" + gameId +
                ", answer='" + answer + '\'' +
                ", states='" + states + '\'' +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                '}';
    }


}

