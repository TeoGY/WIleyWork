package com.example.guessthenumber.service;

import com.example.guessthenumber.models.Game;
import com.example.guessthenumber.models.Round;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class GameService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public int beginGame() {
        // generate an answer and start a new game
        int answer = generateAnswer();
        String sql = "INSERT INTO games (answer, states, start_time) VALUES (?, 'in progress', ?)";
        jdbcTemplate.update(sql, answer, new Date());
        // get the game_id of the newly inserted row
        sql = "SELECT LAST_INSERT_ID()";
        return jdbcTemplate.queryForObject(sql, Integer.class);
    }

    /**
     * This method generates a random 4-digit number by adding random digits (between 0 and 9) to a set until the set has 4 unique digits.
     * It then converts the set to a string and returns the string as an integer.
     *
     */
   /* private int generateAnswer() {
        // generate a random 4-digit number with no duplicate digits
        Set<Integer> digits = new HashSet<>();
        while (digits.size() < 4) {
            digits.add((int) (Math.random() * 10));
        }
        StringBuilder sb = new StringBuilder();
        for (int digit : digits) {
            sb.append(digit);
        }
        return Integer.parseInt(sb.toString());
    }*/

    /**
     * This method generates a list of 4 unique random digits using the ThreadLocalRandom class,
     * and then concatenates the digits to form a 4-digit number.
     * @return the newly generated number
     */
    private int generateAnswer() {
        // generate a list of 4 unique random digits
        List<Integer> digits = new ArrayList<>();
        while (digits.size() < 4) {
            int digit = ThreadLocalRandom.current().nextInt(0, 10);
            if (!digits.contains(digit)) {
                digits.add(digit);
            }
        }
        // concatenate the digits to form a 4-digit number
        int answer = 0;
        for (int digit : digits) {
            answer = answer * 10 + digit;
        }
        System.out.println(answer);
        return answer;

    }


    public Round makeGuess(int gameId, int guess) {
        // make a guess for the specified game
        String sql = "SELECT answer, states FROM games WHERE game_id = ?";
        Game game = jdbcTemplate.queryForObject(sql, new Object[]{gameId}, (rs, rowNum) -> {
            Game g = new Game();
            g.setAnswer(rs.getString("answer"));
            g.setStates(rs.getString("states"));
            return g;
        });
        // check if the game is finished
        if (game.getStates().equals("finished")) {
            throw new IllegalStateException("The game is already finished");
        }
        // calculate the number of exact and partial matches
        int exactMatches = 0;
        int partialMatches = 0;
        String answerStr = String.valueOf(game.getAnswer());
        String guessStr = String.valueOf(guess);
        for (int i = 0; i < 4; i++) {
            if (answerStr.charAt(i) == guessStr.charAt(i)) {
                exactMatches++;
            } else if (answerStr.contains(String.valueOf(guessStr.charAt(i)))) {
                partialMatches++;
            }
        }
        // create a new round with the results
        Round round = new Round();
        round.setGameId(gameId);
        round.setGuess(guess);
        round.setTime(new Date());
        round.setExactMatches(exactMatches);
        round.setPartialMatches(partialMatches);
        // insert the round into the database
        sql = "INSERT INTO rounds (game_id, guess, time, exact_matches, partial_matches) VALUES (?, ?, ?, ?, ?)";
        jdbcTemplate.update(sql, gameId, guess, new Date(), exactMatches, partialMatches);
        // check if the guess is correct
        if (exactMatches == 4) {
            // mark the game as finished
            sql = "UPDATE games SET states = 'finished', end_time = ? WHERE game_id = ?";
            jdbcTemplate.update(sql, new Date(), gameId);
        }
        return round;
    }

    public Game getGame(int gameId) {
        // get the game for the specified game_id
        String sql = "SELECT * FROM games WHERE game_id = ?";
        return jdbcTemplate.queryForObject(sql, new Object[]{gameId}, (rs, rowNum) -> {
            Game game = new Game();
            game.setGameId(rs.getInt("game_id"));
            game.setAnswer(rs.getString("answer"));
            game.setStates(rs.getString("states"));
            game.setStartTime(rs.getDate("start_time"));
            game.setEndTime(rs.getDate("end_time"));
            return game;
        });
    }

    public List<Game> getGames() {
        // get all games from the database
        String sql = "SELECT * FROM games";
        return jdbcTemplate.query(sql, (rs, rowNum) -> {
            Game game = new Game();
            game.setGameId(rs.getInt("game_id"));
            game.setAnswer(rs.getString("answer"));
            game.setStates(rs.getString("states"));
            game.setStartTime(rs.getDate("start_time"));
            game.setEndTime(rs.getDate("end_time"));
            return game;
        });
    }

    public List<Round> getRounds(int gameId) {
        // get all rounds for the specified game_id, sorted by time
        String sql = "SELECT * FROM rounds WHERE game_id = ? ORDER BY time ASC";
        return jdbcTemplate.query(sql, new Object[]{gameId}, (rs, rowNum) -> {
            Round round = new Round();
            round.setRoundId(rs.getInt("round_id"));
            round.setGameId(rs.getInt("game_id"));
            round.setGuess(rs.getInt("guess"));
            round.setTime(rs.getTimestamp("time"));
            round.setExactMatches(rs.getInt("exact_matches"));
            round.setPartialMatches(rs.getInt("partial_matches"));
            return round;
        });
    }
}

