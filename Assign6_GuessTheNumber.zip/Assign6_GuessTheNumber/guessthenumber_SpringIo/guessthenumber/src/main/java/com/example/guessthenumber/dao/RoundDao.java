package com.example.guessthenumber.dao;

import com.example.guessthenumber.models.Round;

import java.util.List;

public interface RoundDao {
    List<Round> getAllRounds();
    Round getRoundById(int roundId);
    List<Round> getRoundsByGameId(int gameId);
    void addRound(Round round);
    void updateRound(Round round);
}
