package com.example.guessthenumber.controller;

import com.example.guessthenumber.models.Game;
import com.example.guessthenumber.models.Round;
import com.example.guessthenumber.service.GameService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/game")
public class GameController {
    @Autowired
    private GameService gameService;

    @PostMapping("/begin")
    public ResponseEntity<Integer> begin() {
        int gameId = gameService.beginGame();
        return new ResponseEntity<>(gameId, HttpStatus.CREATED);
    }

    @PostMapping("/guess/{gameId}")
    public Round guess(@PathVariable int gameId, @RequestParam int guess) {
        return gameService.makeGuess(gameId, guess);
    }

    @GetMapping
    public List<Game> getGames() {
        return gameService.getGames();
    }

    @GetMapping("/{gameId}")
    public Game getGame(@PathVariable int gameId) {
        return gameService.getGame(gameId);
    }

    @GetMapping("/rounds/{gameId}")
    public List<Round> getRounds(@PathVariable int gameId) {
        return gameService.getRounds(gameId);
    }
}
