package com.example.guessthenumber.dao;

import com.example.guessthenumber.models.Game;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class GameDBDao implements GameDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<Game> getAllGames() {
        return jdbcTemplate.query("SELECT * FROM games", new GameRowMapper());
    }

    @Override
    public Game getGameById(int gameId) {
        return jdbcTemplate.queryForObject("SELECT * FROM games WHERE game_id = ?", new Object[] {gameId}, new GameRowMapper());
    }

    @Override
    @Transactional
    public void addGame(Game game) {
        jdbcTemplate.update("INSERT INTO games (game_id, answer, states, start_time, end_time) VALUES (?, ?, ?, ?, ?)",
                game.getGameId(),
                game.getAnswer(),
                game.getStates(),
                game.getStartTime(),
                game.getEndTime());
    }

    @Override
    public void updateGame(Game game) {
        jdbcTemplate.update("UPDATE games SET answer = ?, states = ?, start_time = ?, end_time = ? WHERE game_id = ?",
                game.getAnswer(),
                game.getStates(),
                game.getStartTime(),
                game.getEndTime(),
                game.getGameId());
    }

    private static class GameRowMapper implements RowMapper<Game> {
        @Override
        public Game mapRow(ResultSet rs, int rowNum) throws SQLException {
            Game game = new Game();
            game.setGameId(rs.getInt("game_id"));
            game.setAnswer(rs.getString("answer"));
            game.setStates(rs.getString("states"));
            game.setStartTime(rs.getDate("start_time"));
            game.setEndTime(rs.getDate("end_time")); // game.setEndTime(rs.getDate("end_time"));
            return game;
        }
    }
}

