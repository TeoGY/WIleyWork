package com.example.guessthenumber.dao;

import com.example.guessthenumber.models.Game;

import java.util.List;

public interface GameDao {
    List<Game> getAllGames();
    Game getGameById(int gameId);
    void addGame(Game game);
    void updateGame(Game game);

}

