import java.util.ArrayList;

public class DVDObject {
    private String title;
    private String releaseDate;
    private String mpaaRating;
    private String dName;
    private String studio;
    private String uRate;

    //Constructor
    public DVDObject(String title, String releaseDate, String mpaaRating, String dName, String studio, String uRate){
        this.title = title;
        this.releaseDate = releaseDate;
        this.mpaaRating = mpaaRating;
        this.dName = dName;
        this.studio = studio;
        this.uRate = uRate;
        listDVD.add(this); // Each time a dvd object is constructed, add that copy to the Arraylist

    }

    /*
    Can be shared out to other classes
    One copy for all DVDs
    <DVDObject> allows us to still access the DVD functionality
    */

    public static ArrayList<DVDObject> listDVD = new ArrayList<>();



    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }


    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }


    public String getMpaaRating() {
        return mpaaRating;
    }

    public void setMpaaRating(String mpaaRating) {
        this.mpaaRating = mpaaRating;
    }


    public String getdName() {
        return dName;
    }

    public void setdName(String dName) {
        this.dName = dName;
    }


    public String getStudio() {
        return studio;
    }

    public void setStudio(String studio) {
        this.studio = studio;
    }


    public String getuRate() {
        return uRate;
    }

    public void setuRate(String uRate) {
        this.uRate = uRate;
    }


    public String toString() {
        return "Movie List " +
                "title='" + title + '\'' +
                ", releaseDate=" + releaseDate +
                ", mpaaRating='" + mpaaRating + '\'' +
                ", dName='" + dName + '\'' +
                ", studio='" + studio + '\'' +
                ", uRate='" + uRate + '\''
                ;

    }
}// End of Class
