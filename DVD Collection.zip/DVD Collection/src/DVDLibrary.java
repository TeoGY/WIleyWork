import java.io.*; // Using read and write functionality to a file
import java.util.Scanner;

public class DVDLibrary {

    /**
     * Instantiates the main method of this program
     * @param args
     * @throws InterruptedException
     */
    public static void main(String[] args) throws InterruptedException {
        String fileName = "dvd.txt"; // Make the dvd text file into a String
        File dvdFile = new File(fileName); // File object
        //FileReader fReader;

        try {
            FileReader fReader = new FileReader(dvdFile); // Use file object for file reader
            BufferedReader bReader = new BufferedReader(fReader); //Read it line by line
            String line = bReader.readLine();

            while (line != null) { // Check if there are lines to read,
                //System.out.println(line);

                String[] contents = line.split(","); //Separate the DVD files content
                line = bReader.readLine(); // Continue reading

                //Structure "contents" array
                String title = contents[0];
                String releaseDate = contents[1];
                String mpaaRating = contents[2];
                String dName = contents[3];
                String studio = contents[4];
                String uRate = contents[5];

                //Creates a DVD object of type DVD
                DVDObject dvds = new DVDObject(title, releaseDate, mpaaRating, dName, studio, uRate);

            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // Menu that shows user DVD Menu options
        Scanner menu = new Scanner(System.in);
        int menuOption = 0;
        do {
            System.out.println();
            System.out.println("=== DVD MENU ===");
            System.out.println("1. List of DVDs in our collection"); // List of movies in the collection
            System.out.println("2. Find DVD by Title");
            System.out.println("3. Add DVD to collection");
            System.out.println("4. Edit Menu");
            System.out.println("5. Delete Movie by Title");
            System.out.println("6. Exit");
            System.out.println("Input a number to navigate menu");
            menuOption = menu.nextInt(); // Takes input between 1 - 6 that allows for different DVD Library functionality

            switch (menuOption) {
                case 1:
                    // System.out.println(DVDObject.listDVD); All films on a single line
                    listDVDs();
                    break;

                case 2:
                    findDVDByTitle(); // Finds if movie name is in list
                    break;

                case 3:
                    addMovie();
                    break;

                case 4:
                    editDVD(0);
                    //editTitle(" ");
                    break;
                case 5:
                    deleteDVDByTitle();
                    break;
                case 6:
                    // "Exit, writes to new text file with updated collection
                    System.out.println("Exiting...");
                    Thread.sleep(2000); // Exit after 2 seconds
                    saveNewDVDFile();
            }
        } while (menuOption != 6);



    } // End of Main

    /**
     * Once user has finished in the DVD library, creates a new DVD text file,
     * and writes the state of the current to the new text file.
     */
    public static void saveNewDVDFile(){

        System.out.println("Changes have been saved to newDVD.txt");
        String newFileName = "newDVD.txt"; 
        File newFile = new File(newFileName);

        try{
            FileWriter fWriter = new FileWriter(newFile);
            BufferedWriter bWriter = new BufferedWriter(fWriter);

            for (DVDObject newDVD: DVDObject.listDVD) {
                String emptyDVD = " ";
                emptyDVD = newDVD.getTitle() + ","
                        + newDVD.getReleaseDate()+ ","
                        + newDVD.getMpaaRating()+ ","
                        + newDVD.getdName()+ ","
                        + newDVD.getStudio()+ ","
                        + newDVD.getuRate() + "\n"; // Start new line
                bWriter.write(emptyDVD);
            }
            bWriter.flush();
            bWriter.close();

        } catch(Exception e){
            e.printStackTrace();
        }
    }

    /**
     * Prints a list with all the current films in the collection
     */
    public static void listDVDs() {
        for (int i = 0; i < DVDObject.listDVD.size(); i++){

            System.out.println(DVDObject.listDVD.get(i));
        }
    }

    /**
     * Checks the DVD list and prints if the film is in the list
     */
    public static boolean findDVDByTitle() {
        Scanner sc = new Scanner(System.in);
        String dvdTitle = " ";
        System.out.println("Enter the title of the film");
        dvdTitle = sc.nextLine();


        for (int i = 0; i < DVDObject.listDVD.size(); i++){ // Go through list starting at the first value and find if a movie is in the list

            if (DVDObject.listDVD.get(i).getTitle().equalsIgnoreCase(dvdTitle)) { // Find match that ignores casing

                System.out.println("Yes, We have " + dvdTitle + " in our collection"); // updates user
                return true;
            }
        }
        return false;
    }



    /**
     * A movie to the collection
     */
    public static void addMovie(){
        Scanner sc = new Scanner(System.in);
        String newData = " ";
        newData = sc.nextLine();

        boolean x = findDVDByTitle();
        if (x) {
            System.out.println("Movie found");
        } else {
            DVDObject.listDVD.add(new DVDObject(newData, null, null, null, null, null));
            System.out.println(newData + " has been added");
        }
    }

    /**
     * Removes a movie from the collection
     */
    public static void deleteDVDByTitle() {
        Scanner sc = new Scanner(System.in);
        String tDelete = " ";
        System.out.println("Enter the title you wish deleted");
        tDelete = sc.nextLine();

        for(int i = 0; i < DVDObject.listDVD.size(); i++){

            if  (DVDObject.listDVD.get(i).getTitle().equalsIgnoreCase(tDelete)) { // Find the title of the movie we wish removed

                System.out.println(DVDObject.listDVD.get(i).toString());
                DVDObject.listDVD.remove(DVDObject.listDVD.get(i)); //remove from Arraylist
                System.out.println(tDelete + " has been removed from the collection"); //Update user of changes
            } else {
                System.out.println(tDelete +" isn't listed");
                break;
            }
        }
    }

    /**
     * Beginning of all Edit functionality
     * @param editOption The input between 1 - 7 which initiates different edit methods
     */
    public static void editDVD(int editOption) {
        Scanner menuNo = new Scanner(System.in);
        do {
            printEditMenu();
            System.out.println("Enter a number from the menu");
            editOption = menuNo.nextInt();

            //Switch case through edit functionality
            switch (editOption) {
                case 1:
                    editTitle();
                    break;
                case 2:
                    editReleaseDate();
                    break;
                case 3:
                    editMPAARating();
                    break;
                case 4:
                    editDirector();
                    break;
                case 5:
                    editStudio();
                    break;
                case 6:
                    editUserRating();
                    break;
                case 7:
            }
        } while (editOption != 7);
    }

    /**
     * Prints a new menu to the user that allows them to navigate edit functionality
     */
    public static void printEditMenu(){
        System.out.println("=== Edit Menu ===");
        System.out.println("1. Edit Title ");
        System.out.println("2. Edit ReleaseDate");
        System.out.println("3. Edit MPAA Rating");
        System.out.println("4. Edit Director name");
        System.out.println("5. Edit Studio");
        System.out.println("6. Edit User Rating");
        System.out.println("7. Return");
    }

    /**
     *  Allow the user to edit the review from their selected film
     */
    public static void editTitle(){
        Scanner sc = new Scanner(System.in);
        String tDelete= " ";
        String newData = " ";
        System.out.println("Enter the movie you wish to edit");
        tDelete = sc.nextLine();
        System.out.println("What do you wish to rename");
        newData = sc.nextLine();

        for(int i = 0; i < DVDObject.listDVD.size(); i++){


            if  (DVDObject.listDVD.get(i).getTitle().equalsIgnoreCase(tDelete)) {
                    //System.out.println(DVDObject.listDVD.get(i).toString());
                    //DVDObject.listDVD.remove(DVDObject.listDVD.get(i));
                    DVDObject.listDVD.get(i).setTitle(newData);
                    //DVDObject.listDVD.add(DVDObject.listDVD.get(i));
                    System.out.println(tDelete+ " has been renamed");
                    System.out.println(DVDObject.listDVD.get(i).toString());

            }
        }
    }

    /**
     * Allow the user to edit the review from their selected film
     */
    public static void editReleaseDate() {
        Scanner sc = new Scanner(System.in);
        String tDelete = " ";
        String newData = " ";
        System.out.println("Enter the movie you wish to edit");
        tDelete = sc.nextLine();
        System.out.println("What do you wish to rename");
        newData = sc.nextLine();

        for (int i = 0; i < DVDObject.listDVD.size(); i++) {

            if (DVDObject.listDVD.get(i).getTitle().equalsIgnoreCase(tDelete)) {
                DVDObject.listDVD.get(i).setReleaseDate(newData);
                System.out.println(tDelete + " release date was changed:");
                System.out.println(DVDObject.listDVD.get(i).toString());

            }
        }
    }

    /**
     * Allow the user to edit the review from their selected film
     */
    public static void editMPAARating(){
        Scanner sc = new Scanner(System.in);
        String tDelete = " ";
        String newData = " ";
        System.out.println("Enter the movie you wish to edit");
        tDelete = sc.nextLine();
        System.out.println("What do you wish to rename");
        newData = sc.nextLine();

        for (int i = 0; i < DVDObject.listDVD.size(); i++) {


            if (DVDObject.listDVD.get(i).getTitle().equalsIgnoreCase(tDelete)) {
                DVDObject.listDVD.get(i).setMpaaRating(newData);
                System.out.println(tDelete + " MPAA rating was changed:");
                System.out.println(DVDObject.listDVD.get(i).toString());
            }
        }
    }

    /**
     *  Allow the user to edit the review from their selected film
     */
    public static void editDirector(){
        Scanner sc = new Scanner(System.in);
        String tDelete = " ";
        String newData = " ";
        System.out.println("Enter the movie you wish to edit");
        tDelete = sc.nextLine();
        System.out.println("What do you wish to rename");
        newData = sc.nextLine();

        for (int i = 0; i < DVDObject.listDVD.size(); i++) {


            if (DVDObject.listDVD.get(i).getTitle().equalsIgnoreCase(tDelete)) {
                DVDObject.listDVD.get(i).setdName(newData);
                System.out.println(tDelete + " director was changed:");
                System.out.println(DVDObject.listDVD.get(i).toString());

            }
        }
    }

    /**
     *
     *  Allow the user to edit the studio from their selected film
     */
    public static void editStudio(){
        Scanner sc = new Scanner(System.in);
        String tDelete = " ";
        String newData = " ";
        System.out.println("Enter the movie you wish to edit");
        tDelete = sc.nextLine();
        System.out.println("Which studio made this movie");
        newData = sc.nextLine();

        for (int i = 0; i < DVDObject.listDVD.size(); i++) {


            if (DVDObject.listDVD.get(i).getTitle().equalsIgnoreCase(tDelete)) {
                DVDObject.listDVD.get(i).setStudio(newData);

                System.out.println(tDelete + " has been renamed");
                System.out.println(DVDObject.listDVD.get(i).toString());

            }
        }
    }

    /**
     * Allow the user to edit the review from their selected film
     */
    public static void editUserRating(){
        Scanner sc = new Scanner(System.in);
        String tDelete = " ";
        String newData = " ";
        System.out.println("Enter the movie you wish to edit");
        tDelete = sc.nextLine();
        System.out.println("Write your new review");
        newData = sc.nextLine();

        for (int i = 0; i < DVDObject.listDVD.size(); i++) {


            if (DVDObject.listDVD.get(i).getTitle().equalsIgnoreCase(tDelete)) {
                DVDObject.listDVD.get(i).setuRate(newData);
                System.out.println(tDelete + " has been renamed");
                System.out.println(DVDObject.listDVD.get(i).toString());
            }
        }
    } // Final Edit functionality

} // End of Class