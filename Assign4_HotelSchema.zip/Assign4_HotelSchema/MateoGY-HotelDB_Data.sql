-- -----------------------------------------------------
-- Part 2: Define the Database
-- -----------------------------------------------------

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';


DROP SCHEMA IF EXISTS `mydb` ;

CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8 ;

USE `mydb` ;

DROP TABLE IF EXISTS `mydb`.`RoomType` ;

CREATE TABLE IF NOT EXISTS `mydb`.`RoomType` (
  `RoomTypeID` INT NOT NULL,
  `RoomType` VARCHAR(6) NOT NULL,
  `RoomPrice` FLOAT NOT NULL,
  `RoomExtraPersonPrice` FLOAT NOT NULL,
  `adaAccessible` TINYINT NOT NULL,
  `StandardOccupancy` TINYINT NOT NULL,
  `MaximumOccupancy` TINYINT NOT NULL,
  PRIMARY KEY (`RoomTypeID`));

DROP TABLE IF EXISTS `mydb`.`Amenities` ;

CREATE TABLE IF NOT EXISTS `mydb`.`Amenities` (
  `AmenitiesID` INT NOT NULL AUTO_INCREMENT,
  `Name` VARCHAR(50) NOT NULL,
  `Price` FLOAT NOT NULL,
  PRIMARY KEY (`AmenitiesID`));

DROP TABLE IF EXISTS `mydb`.`Room` ;

CREATE TABLE IF NOT EXISTS `mydb`.`Room` (
  `RoomID` INT NOT NULL,
  `TypeID` INT NOT NULL,
  PRIMARY KEY (`RoomID`, `TypeID`),
  INDEX `fk_TypeID_idx` (`TypeID` ASC) VISIBLE,
  CONSTRAINT `fk_TypeID`
    FOREIGN KEY (`TypeID`)
    REFERENCES `mydb`.`RoomType` (`RoomTypeID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `mydb`.`AmenitiestoRoom` ;

CREATE TABLE IF NOT EXISTS `mydb`.`AmenitiestoRoom` (
  `RoomID` INT NOT NULL,
  `AmenitiesID` INT NOT NULL,
  PRIMARY KEY (`RoomID`, `AmenitiesID`),
  INDEX `fk_AmenitiesID_idx` (`AmenitiesID` ASC) VISIBLE,
  CONSTRAINT `fk_AmenitiesID`
    FOREIGN KEY (`AmenitiesID`)
    REFERENCES `mydb`.`Amenities` (`AmenitiesID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_RoomID`
    FOREIGN KEY (`RoomID`)
    REFERENCES `mydb`.`Room` (`RoomID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);

DROP TABLE IF EXISTS `mydb`.`Reservations` ;

CREATE TABLE IF NOT EXISTS `mydb`.`Reservations` (
  `ReservationID` INT NOT NULL AUTO_INCREMENT,
  `Arrival` DATE NOT NULL,
  `Departure` DATE NOT NULL,
  `NumberOfAdults` TINYINT NOT NULL,
  `NumberOfChildren` TINYINT NOT NULL,
  PRIMARY KEY (`ReservationID`),
  UNIQUE INDEX `idReservation_UNIQUE` (`ReservationID` ASC) VISIBLE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;



DROP TABLE IF EXISTS `mydb`.`Guest` ;

CREATE TABLE IF NOT EXISTS `mydb`.`Guest` (
  `GuestID` INT NOT NULL AUTO_INCREMENT,
  `Name` VARCHAR(50) NOT NULL,
  `Address` VARCHAR(100) NOT NULL,
  `City` VARCHAR(30) NOT NULL,
  `State` VARCHAR(30) NOT NULL,
  `Zip` INT NOT NULL,
  `Phone` VARCHAR(15) NOT NULL,
  PRIMARY KEY (`GuestID`),
  UNIQUE INDEX `idGuest_UNIQUE` (`GuestID` ASC) VISIBLE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `mydb`.`ReservationGuest` ;

CREATE TABLE IF NOT EXISTS `mydb`.`ReservationGuest` (
  `ReservationID` INT NOT NULL,
  `GuestID` INT NOT NULL,
  `RoomID` INT NOT NULL,
  PRIMARY KEY (`ReservationID`, `GuestID`, `roomID`),
  INDEX `fk_GuestID_idx` (`GuestID` ASC) VISIBLE,
  INDEX `fk_RoomID_idx` (`roomID` ASC) VISIBLE,
  CONSTRAINT `fk_ReservationID`
    FOREIGN KEY (`ReservationID`)
    REFERENCES `mydb`.`Reservations` (`ReservationID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_GuestID`
    FOREIGN KEY (`GuestID`)
    REFERENCES `mydb`.`Guest` (`GuestID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_RoomID_Reservation`
    FOREIGN KEY (`roomID`)
    REFERENCES `mydb`.`Room` (`RoomID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

-- -----------------------------------------------------
-- Part 2: Manage the Data
-- -----------------------------------------------------

INSERT INTO RoomType(RoomTypeID,RoomType,RoomPrice,RoomExtraPersonPrice,adaAccessible,StandardOccupancy,MaximumOccupancy) VALUES
("1","Single","149.99","0","0","2","2"),
("2","Single","149.99","0","1","2","2"),
("3","Double","174.99","10","0","2","4"),
("4","Double","174.99","10","1","2","4"),
("5","Suite","399.99","20","1","2","2");

INSERT INTO Amenities(Name,Price) VALUES
("Microwave","0"),
("Refrigerator","0"),
("Jacuzzi","25"),
("Kitchen","0");

INSERT INTO Room(RoomID,TypeID) VALUES
("201","3"),
("202","4"),
("203","3"),
("204","4"),
("205","1"),
("206","2"),
("207","1"),
("208","2"),
("301","3"),
("302","4"),
("303","3"),
("304","4"),
("305","1"),
("306","2"),
("307","1"),
("308","2"),
("401","5"),
("402","5");

INSERT INTO AmenitiestoRoom (RoomID,AmenitiesID) VALUES
("201","1"),
("201","3"),
("202","2"),
("203","1"),
("203","3"),
("204","2"),
("205","1"),
("205","2"),
("205","3"),
("206","1"),
("206","2"),
("207","1"),
("207","2"),
("207","3"),
("208","1"),
("208","2"),
("301","1"),
("301","3"),
("302","2"),
("303","1"),
("303","3"),
("304","2"),
("305","1"),
("305","2"),
("305","3"),
("306","1"),
("306","2"),
("307","1"),
("307","2"),
("307","3"),
("308","1"),
("308","2"),
("401","1"),
("401","2"),
("401","4"),
("402","1"),
("402","2"),
("402","4");

INSERT INTO Reservations(Arrival,Departure,NumberOfAdults,NumberOfChildren)VALUES
("2023-02-02","2023-02-04","1","0"),
("2023-02-05","2023-02-10","2","1"),
("2023-02-22","2023-02-24","2","0"),
("2023-03-06","2023-03-07","2","2"),
("2023-03-17","2023-03-20","1","1"),
("2023-03-18","2023-03-23","3","0"),
("2023-03-29","2023-03-31","2","2"),
("2023-03-31","2023-04-05","2","0"),
("2023-04-09","2023-04-13","1","0"),
("2023-04-23","2023-04-24","1","1"),
("2023-05-30","2023-06-02","2","4"),
("2023-06-10","2023-06-14","2","0"),
("2023-06-10","2023-06-14","1","0"),
("2023-06-17","2023-06-18","3","0"),
("2023-06-28","2023-07-02","2","0"),
("2023-07-13","2023-07-14","3","1"),
("2023-07-18","2023-07-21","4","2"),
("2023-07-28","2023-07-29","2","1"),
("2023-08-30","2023-09-01","1","0"),
("2023-09-16","2023-09-17","2","0"),
("2023-09-13","2023-09-15","2","2"),
("2023-11-22","2023-11-25","2","2"),
("2023-11-22","2023-11-25","2","0"),
("2023-11-22","2023-11-25","2","2"),
("2023-12-24","2023-12-28","2","0");

INSERT INTO Guest(Name,Address,City,State,Zip,Phone) VALUES
("Mateo Guembe-Young","South East","London","London","12131","01234567891"),
("Mack Simmer","379 Old Shore Street","Council Bluffs","IA","51501","(291) 553-0508"),
("Bettyann Seery","750 Wintergreen Dr.","Wasilla","AK","99654","(478) 277-9632"),
("Duane Cullison","9662 Foxrun Lane","Harlinge","TX","78552","(308) 494-0198"),
("Karie Yang","9378 W. Augusta Ave.","West Deptford","NJ","08096","(214) 730-0298"),
("Aurore Lipton","762 Wild Rose Street","Saginaw","MI","48601","(377) 507-0974"),
("Zachery Luechtefeld","7 Poplar Dr.","Arvada","CO","80003","(814) 485-2615"),
("Jeremiah Pendergrass","70 Oakwood St.","Zion","IL","60099","(279) 491-0960"),
("Walter Holaway","7556 Arrowhead St.","Cumberland","RI","02864","(446) 396-6785"),
("Wilfred Vise","77 West Surrey Street","Oswego","NY","13126","(834) 727-1001"),
("Maritza Tilton","939 Linda Rd.","Burke","VA","22015","(446) 351-6860"),
("Joleen Tison","87 Queen St.","Drexel Hill","PA","19026","(231) 893-2755");

INSERT INTO ReservationGuest(ReservationID,GuestID,RoomID) VALUES
("1","2","308"),
("2","3","203"),
("3","4","305"),
("4","5","201"),
("5","1","307"),
("6","6","302"),
("7","7","202"),
("8","8","304"),
("9","9","301"),
("10","10","207"),
("11","11","401"),
("12","12","206"),
("13","12","208"),
("14","6","304"),
("15","1","205"),
("16","9","204"),
("17","10","401"),
("18","3","303"),
("19","3","305"),
("20","2","208"),
("21","5","203"),
("22","4","401"),
("23","2","206"),
("24","2","301"),
("25","11","302");
