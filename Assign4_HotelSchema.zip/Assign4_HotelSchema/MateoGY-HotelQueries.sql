use mydb;

/*
1. Write a query that returns a list of reservations that end in July 2023,
 including the name of the guest, the room number(s), and the reservation dates.
*/

SELECT Name, RoomID as RoomNumber, Arrival, Departure FROM Guest
JOIN ReservationGuest USING(GuestID)
JOIN Reservations USING(ReservationID)
WHERE MONTH(Departure) = 7 
ORDER BY ReservationID;

/*
RESULT QUERY 1:

Name			    RoomNumber  Arrival	  	Departure
Mateo Guembe-Young	205	  		2023-06-28  2023-07-02
Walter Holaway	  	204	  		2023-07-13  2023-07-14
Wilfred Vise	  	401	  		2023-07-18  2023-07-21
Bettyann Seery	  	303	  		2023-07-28  2023-07-29
*/

/*
2. Write a query that returns a list of all reservations for rooms with a jacuzzi,
 displaying the guest's name, the room number, and the dates of the reservation.
*/

SELECT c.Name, RoomID as RoomNumber, Arrival, Departure FROM Guest c
JOIN ReservationGuest USING(GuestID)
JOIN Reservations USING(ReservationID)
JOIN Room USING(RoomID)
JOIN AmenitiestoRoom USING(RoomID)
JOIN Amenities a USING (AmenitiesID)
WHERE a.Name = 'Jacuzzi'
ORDER BY ReservationID;

/*
RESULT QUERY 2:

Name			    RoomNumber  Arrival	  	Departure
Bettyann Seery		203			2023-02-05	2023-02-10
Duane Cullison		305			2023-02-22	2023-02-04
Karie Yang			201			2023-03-06	2023-03-07
Mateo Guembe-Young	307			2023-03-17	2023-03-20
Walter Holaway		301			2023-04-09	2023-04-13
Wilfred Vise		207			2023-04-23	2023-04-24
Mateo Guembe-Young	205			2023-06-28	2023-07-02
Bettyann Seery		303			2023-07-28	2023-07-29
Bettyann Seery		305			2023-08-30	2023-09-01
Karie Yang			203			2023-09-13	2023-09-15
Mack Simmer			301			2023-11-22	2023-11-25
*/

/*
3. Write a query that returns all the rooms reserved for a specific guest,
 including the guest's name, the room(s) reserved, the starting date of the reservation,
 and how many people were included in the reservation. (Choose a guest's name from the existing data.)
*/

SELECT g.Name, RoomID as RoomNumber, Arrival, NumberOfAdults+NumberOfChildren as NumberOfGuests FROM Guest g -- ReservationID is not required in the task, but it looks neat. Is it needed tho? Probably not.
JOIN ReservationGuest USING(GuestID)
JOIN Reservations USING(ReservationID)
JOIN Room USING(RoomID)
WHERE g.NAME = "Mack Simmer"
ORDER BY ReservationID;

/*
RESULT QUERY 3:

Name			    RoomNumber  Arrival	  	NumberOfGuests
Mack Simmer			308			2023-02-02	1
Mack Simmer			208			2023-09-16	2
Mack Simmer			206			2023-11-22	2
Mack Simmer			301			2023-11-22	4
*/

/*
4.  Write a query that returns a list of rooms, reservation ID, and per-room cost for each reservation. 
The results should include all rooms, whether or not there is a reservation associated with the room.
*/

SELECT r.RoomNumber, r.ReservationID, MAX(r.TotalCost) AS Cost FROM(
SELECT Room.RoomID as RoomNumber, ReservationGuest.ReservationID, 
	CASE
    WHEN (Reservations.NumberOfAdults - RoomType.StandardOccupancy)>0 AND EXISTS (SELECT Room.RoomID FROM Room WHERE AmenitiestoRoom.AmenitiesID = 3 )	
    THEN ROUND((RoomType.RoomPrice + 25 ) * DATEDIFF(Reservations.Departure, Reservations.Arrival)  + (Reservations.NumberOfAdults - RoomType.StandardOccupancy)*RoomType.RoomExtraPersonPrice ,2)
    WHEN (Reservations.NumberOfAdults - RoomType.StandardOccupancy)>0 AND EXISTS (SELECT Room.RoomID FROM Room WHERE AmenitiestoRoom.AmenitiesID <> 3 )	
    THEN ROUND(RoomType.RoomPrice * DATEDIFF(Reservations.Departure, Reservations.Arrival)  + (Reservations.NumberOfAdults - RoomType.StandardOccupancy)*RoomType.RoomExtraPersonPrice ,2)
    WHEN (Reservations.NumberOfAdults - RoomType.StandardOccupancy)<=0 AND EXISTS (SELECT Room.RoomID FROM Room WHERE AmenitiestoRoom.AmenitiesID = 3 )	
    THEN ROUND((RoomType.RoomPrice + 25 ) * DATEDIFF(Reservations.Departure, Reservations.Arrival) ,2)
    WHEN (Reservations.NumberOfAdults - RoomType.StandardOccupancy)<=0 AND EXISTS (SELECT Room.RoomID FROM Room WHERE AmenitiestoRoom.AmenitiesID <> 3 )	
	THEN ROUND(RoomType.RoomPrice * DATEDIFF(Reservations.Departure, Reservations.Arrival) ,2) END AS TotalCost
FROM Room 
JOIN ReservationGuest ON Room.RoomID=ReservationGuest.RoomID
JOIN Reservations ON Reservations.ReservationID=ReservationGuest.ReservationID
JOIN RoomType ON Room.TypeID=RoomType.RoomTypeID
JOIN AmenitiestoRoom ON Room.RoomID=AmenitiestoRoom.RoomID
JOIN Amenities ON AmenitiestoRoom.AmenitiesID=Amenities.AmenitiesID
) as r GROUP BY RoomNumber, ReservationID
ORDER BY RoomNumber;


/*
RoomNumber  ReservationID	TotalCost
201			4				199.99
202			7				349.98
203			2				999.95
203			21				399.98
204			16				184.99
205			15				599.96
206			23				699.96
206			12				449.97
207			10				174.99
208			13				599.96
208			20				149.99
301			9				799.96
301			24				599.97
302			6				884.95
302			25				699.96
303			18				199.99
304			8				874.95
304			14				184.99
305			3				349.98
305			19				349.98
307			5				524.97
308			1				299.98
401			11				1199.97
401			17				1239.97
401			22				1199.97
*/


/*
5. Write a query that returns all the rooms accommodating at least three guests and that are reserved on any date in April 2023
*/

SELECT RoomID, NumberOfAdults+NumberOfChildren as NumberOfGuests, Arrival FROM Room 
JOIN ReservationGuest USING(roomID)
JOIN Guest USING(GuestID)
JOIN Reservations USING(ReservationID) 
WHERE NumberOfAdults+NumberOfChildren >= 3 AND (MONTH(Arrival) = 4 OR MONTH(Departure) = 4); 

/*
RoomID	NumberOfGuests	Arrival

*/


/*
6. Write a query that returns a list of all guest names and the number of reservations per guest,
 sorted starting with the guest with the most reservations and then by the guest's last name.
*/

SELECT g.Name, COUNT(ReservationID) as NumberOfReservations FROM Guest g
JOIN ReservationGuest USING(GuestID)
JOIN Reservations r USING(ReservationID)
GROUP BY g.Name
ORDER BY NumberOfReservations DESC,SUBSTR(g.Name, INSTR(g.Name, ' '));

/*
RESULT QUERY 6:
Name			    	NumberOfReservations  
Mack Simmer				4
Bettyann Seery			3
Duane Cullison			2
Mateo Guembe-Young		2
Walter Holaway			2
Aurore Lipton			2
Maritza Tilton			2
Joleen Tison			2
Wilfred Vise			2
Karie Yang				2
Zachery Luechtefeld		1
Jeremiah Pendergrass	1	
*/


/*
7. Write a query that displays the name, address, 
and phone number of a guest based on their phone number. (Choose a phone number from the existing data.)
*/

SELECT Name,Address, Phone FROM Guest
WHERE Phone LIKE '%(291) 553-0508%';

/*
RESULT QUERY 7:
Name			 Address 				Phone
Mack Simmer		 379 Old Shore Street	(291) 553-0508
​*/
